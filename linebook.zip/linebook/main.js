var http = require('http');
var fs = require('fs');
var url = require('url');
var qs = require('querystring');
var template = require('./lib/template.js')


//서버 만들기

var app = http.createServer(function(request,response){
	var _url = request.url;
	var queryData = url.parse(_url,true).query;
	var pathname = url.parse(_url,true).pathname;
	if(pathname === '/'){
		if(queryData.id === undefined){
			fs.readdir('linebook/data',function(error,filelist){
				fs.readFile(`linebook/linebook.css`,'utf8',function(err,CSS){
					fs.readFile(`linebook/linebook.js`,'utf8',function(err,JS){
						var title = '선번장.com';
						var list = template.List(filelist,title);
						var HTML = template.HTML(title,CSS,JS,list,"","");
						response.writeHead(200);
						response.end(HTML);
					});
				});		
			});
		}else{
			fs.readdir('linebook/data',function(error,filelist){	
				fs.readFile(`linebook/data/${queryData.id}`,'utf8',function(err,data){		
					fs.readFile(`linebook/linebook.css`,'utf8',function(err,CSS){
						fs.readFile(`linebook/linebook.js`,'utf8',function(err,JS){
							var title = queryData.id;
							var list = template.List(filelist,title);
							var newportform = template.NEWPORTFORM(filelist,title);
							var HTML = template.HTML(title,CSS,JS,list,data,newportform);
							response.writeHead(200);
							response.end(HTML);
						});
					});
				});
			});
		}
		
	//새로운 노드 만들기
	
	}else if(pathname==='/create_newnode'){
		var body = '';
		request.on('data',function(data){
			body = body + data;
		});
		request.on('end',function(){
			var post = qs.parse(body);
			var title = post.node_name;
			var description = '';
			fs.writeFile(`linebook/data/${title}`,description,'utf8',function(err){
				response.writeHead(302, {Location:encodeURI(`/?id=${title}`)})
				response.end();	
			});
		});
		
	//노드 변경사항 저장하기
		
	}else if(pathname==="/save"){
		var body = '';
		request.on('data',function(data){
			body = body + data;
		});
		request.on('end',function(){
			var post = qs.parse(body);
			var thisnode = post.thisnode;
			var save_content = post.save_content;
			fs.unlink(`linebook/data/${thisnode}`,function(err){
			})
			fs.writeFile(`linebook/data/${thisnode}`,save_content,"utf8",function(err){
			})
			response.writeHead(302,{Location:encodeURI(`/?id=${thisnode}`)});
			response.end();	
		});
			
	//새로운 포트 만들기 
		
	}else if(pathname==="/create_newport"){
		var body = '';
		request.on('data',function(data){
			body = body + data;
		});
		request.on('end',function(){
			var post = qs.parse(body);
			var thisnode = post.thisnode;
			var port_name = post.port_name;
			var thisnode = post.thisnode;																			
			var oppnode = post.oppnode;
			var cable_type = post.cable_type;
			var port_type = post.port_type;
			var sharenum = 0;
 			fs.readFile(`linebook/data/${thisnode}`,'utf8',function(err,thiscontent){
				fs.readFile(`linebook/data/${oppnode}`,'utf8',function(err,oppcontent){
					
				//sharenum을 정해준다.
				for(var i = 0;true;i++){
					var patterni1 = new RegExp("<!--shar.numS"+i+"shar.numS-->");
					if(thiscontent.match(patterni1)===null && oppcontent.match(patterni1)===null){	
						sharenum = i;
						break;
					}else{
						continue;
					}
				}
			
				//sharenum을 numin에 넣어준다.
				
				if(port_type==="MDF"){
				var newport = template.MDF100(port_name,thisnode,oppnode,cable_type,sharenum);
				fs.appendFile(`linebook/data/${thisnode}`,newport,'utf8',function(err){
				});
				var oppport = template.MDF100(port_name,oppnode,thisnode,cable_type,sharenum);
				fs.appendFile(`linebook/data/${oppnode}`,oppport,'utf8',function(err){
					response.writeHead(302,{Location:encodeURI(`/?id=${thisnode}`)});
					response.end();	
				});
				}else{
					var newport = template.MDF100(port_name,thisnode,oppnode,cable_type,sharenum);
					fs.appendFile(`linebook/data/${thisnode}`,newport,'utf8',function(err){
					});
					var oppport = template.MDF100(port_name,oppnode,thisnode,cable_type,sharenum);
					fs.appendFile(`linebook/data/${oppnode}`,oppport,'utf8',function(err){
						response.writeHead(302,{Location:encodeURI(`/?id=${thisnode}`)});
						response.end();	
					});
				}
			}); 
		}); 
	}); 	
		
		//node 삭제 --------- 해당 노드를 삭제할 시 그 노드의 있는 포트들의 반대편 노드 단자들이 반대편 노드에 아직 남아있을 시 오류 발생
		// 노드를 삭제하면 해당 노드와 연결된 모든 포트들도 삭제되어야함. or 포트를 삭제할시 반대편 노드가 없는경우 그냥 넘어가는 프로세스 만들기
		
	}else if(pathname==="/delete_process"){
		var body = '';
		request.on('data',function(data){
			body = body + data;
		});
		request.on('end',function(){
			var post = qs.parse(body);
			var id = post.id;
			fs.unlink(`linebook/data/${id}`,function(err){
				response.writeHead(302, {Location:`/`});
				response.end();	
			})
		}); 

//포트 삭제
		
	}else if(pathname==="/delete_port"){
		var body = '';
		request.on('data',function(data){
			body = body + data;
		});
		request.on('end',function(){
			var post = qs.parse(body);
			var thisnode = post.thisnode;
			var oppnode = post.oppnode;
			var numin = post.numin;
			fs.readFile(`linebook/data/${thisnode}`,'utf8',function(err,buffer){
				fs.unlink(`linebook/data/${thisnode}`,function(err){
				})
				var check = buffer.indexOf(`<!--sharenumS${numin}sharenumS-->`);
				var check2 = buffer.indexOf(`<!--sharenumE${numin}sharenumE-->`) + 25 + numin.toString().length;;

				var point1 = buffer.slice(0,check);
				var point2 = buffer.slice(check2);
				fs.writeFile(`linebook/data/${thisnode}`,point1,"utf8",function(err){

				})
				fs.appendFile(`linebook/data/${thisnode}`,point2,"utf8",function(err){

				})
			});	
			fs.readFile(`linebook/data/${oppnode}`,'utf8',function(err,buffer){
				fs.unlink(`linebook/data/${oppnode}`,function(err){
				})
				var check = buffer.indexOf(`<!--sharenumS${numin}sharenumS-->`);
				var check2 = buffer.indexOf(`<!--sharenumE${numin}sharenumE-->`) + 25 + numin.toString().length;;

				var point1 = buffer.slice(0,check);
				var point2 = buffer.slice(check2);
				fs.writeFile(`linebook/data/${oppnode}`,point1,"utf8",function(err){

				})
				fs.appendFile(`linebook/data/${oppnode}`,point2,"utf8",function(err){

				})
				response.writeHead(302,{Location:encodeURI(`/?id=${thisnode}`)});
				response.end();	
			});	
		});

//연결관리 connect_control
		
	}else if(pathname==="/connect_control"){		
		fs.readdir('linebook/data',function(error,filelist){
			fs.readFile(`linebook/connection/connection.css`,'utf8',function(err,CSS){
				fs.readFile(`linebook/connection/connection.js`,'utf8',function(err,JS){
					var title = "connect_control";
					var blank_option = '<option selected value=""></option>';
					var HTML = template.connect_control(CSS,JS,filelist,blank_option,blank_option,"");
					response.writeHead(200);
					response.end(HTML);
				});
			});
		});
	
	//연결관리 중 노드 옵션에 따른 opp노드의 옵션 자동 변화
		
	}else if(pathname==="/connect_search"){		
		var body = '';
		request.on('data',function(data){
			body = body + data;
		});
		request.on('end',function(){
			var post = qs.parse(body);
			var center_name = post.center_name;
			var west_name = post.west_name;
			var east_name = post.east_name;
			var center_change = post.center_change;
			var west_specific = post.west_specific;
			var east_specific = post.east_specific;
			
			console.log(center_name,west_name,east_name,center_change,west_specific,east_specific);
			
			fs.readFile(`linebook/data/${center_name}`,'utf8',function(err,thisnode){

				var content = thisnode;
				var match1 = content.match(/<!--port'.n.d.ti.leS-->/g)
				var match2 = content.match(/<!--port'.n.d.ti.leE-->/g)
				
				var match3 = content.match(/<!--port'.p.r.ti.leS-->/g)
				var match4 = content.match(/<!--port'.p.r.ti.leE-->/g)
				
				var listobject = {};
				var nameobject = {};
				
				//listobject에 현재 노드에 있는 포트들의 반대 노드들을 담고
				//nameobject에 현재 노드에 있는 포트들의 이름을 담는다.
				// \n 때문에 index에 1을 더하거나 1을 빼준다.
				
				if(match1!=null){
					for(var i = 0;i<match1.length;i++){
						var firstIndex = content.indexOf(match1[i])+match1[i].length+1;
						var lastIndex = content.indexOf(match2[i])-1;
						
						var f3Index = content.indexOf(match3[i])+match3[i].length+1;
						var l4Index = content.indexOf(match4[i])-1;
						
						var opplist = content.slice(firstIndex,lastIndex);
						
						// 같은 이름의 반대노드는 한번만 들어가게 하면 안되는 이유: 밑에서 west/east의 값은 east/west에서 없애는데 혹 같은 반대노드로 가는 포트를 이어줄 경우 방법이 없어짐.
					
						listobject[i] = opplist;
						nameobject[i] = content.slice(f3Index,l4Index);
						
						firstIndex = content.indexOf(match1[i]);
						lastIndex = content.indexOf(match4[i])+match4[i].length;
						
						content = content.slice(0,firstIndex)+content.slice(lastIndex);
					}
					
					for(index in listobject){
						
					}
					
					//포트들을 이미 선택해서 값이 있으면 그 선택한 값을 셀렉터에 띄우고 아니면 빈값을 띄운다.
					//이미 선택한 포트가 있을 경우 반대쪽 셀렉터에서 그 포트 이름을 제외시킨다.(같은 포트 두개를 선택해서 연결하는 상황을 배제시키기 위함)
					//이미 선택한 포트가 있지만 노드를 변경했을 경우 반대쪽 셀렉터는 다시 선택하지 않은 상태로 만든다.
					//만약 center_change의 값이 1이라면 (=현재 노드를 변경했다면), 반대노드들은 아무것도 선택하지 않은 상태로 돌아간다.
					
					if(center_change==="0"){
						
						if(west_name === "" && east_name === ""){
							var west_opp = '<option selected value=""></option>';
							for(var index in listobject){
								west_opp += `<option value="${listobject[index]}">${listobject[index]}</option>`;
							}
							var east_opp = west_opp;
						}else if(west_name === "" && east_name !== ""){
							var k = 0;
							var east_opp = `<option selected value="${east_name}">${east_name}</option>`;
							for(var index in listobject){
								if(k===0 && listobject[index]=== east_name){
									k += 1;
									continue;
								}
								east_opp += `<option value="${listobject[index]}">${listobject[index]}</option>`;
							}
							
							var k = 0;
							var west_opp = '<option selected value=""></option>';
							for(var index in listobject){
								if(k===0 && listobject[index]=== east_name){
									k += 1;
									continue;
								}
								west_opp += `<option value="${listobject[index]}">${listobject[index]}</option>`;
							}
						}else if(west_name !== "" && east_name === ""){
							var west_opp = `<option selected value="${west_name}">${west_name}</option>`;
							var k = 0;
							for(var index in listobject){
								if(k===0 && listobject[index]=== west_name){
									k += 1;
									continue;
								}
								west_opp += `<option value="${listobject[index]}">${listobject[index]}</option>`;
							}
				
							var k = 0;
							var east_opp = '<option selected value=""></option>';
							for(var index in listobject){
								if(k===0 && listobject[index]=== west_name){
									k += 1;
									continue;
								}
								east_opp += `<option value="${listobject[index]}">${listobject[index]}</option>`;
							}
						}else{
							var west_opp = `<option selected value="${west_name}">${west_name}</option>`;
							var k = 0;
							var j = 0;
							for(var index in listobject){
								if(k===0 && listobject[index]=== west_name){
									k += 1;
									continue;
								}else if(j===0 && listobject[index] === east_name){
									j += 1;
									continue;
								}
								west_opp += `<option value="${listobject[index]}">${listobject[index]}</option>`;
							}
							
							var k = 0;
							var j = 0;
							var east_opp = `<option selected value="${east_name}">${east_name}</option>`;
							for(var index in listobject){
								if(k===0 && listobject[index]=== east_name){
									k += 1;
									continue;
								}else if(j===0 && listobject[index] === west_name){
									j += 1;
									continue;
								}
								east_opp += `<option value="${listobject[index]}">${listobject[index]}</option>`;
							}
						}
						
					}else{
						var west_opp = '<option selected value=""></option>';
						for(var index in listobject){
							west_opp += `<option value="${listobject[index]}">${listobject[index]}</option>`;
						}
						var east_opp = west_opp;
					}
						
				}
				
				fs.readFile(`linebook/connection/connection.css`,'utf8',function(err,CSS){
					fs.readFile(`linebook/connection/connection.js`,'utf8',function(err,JS){
						fs.readdir('linebook/data',function(error,filelist){
							var HTML = template.connect_control(CSS,JS,filelist,west_opp,east_opp,center_name,'<option selected value="test">test</option>','<option selected value="test">test</option>');
							response.writeHead(200);
							response.end(HTML);
						});
					});
				});
			});
				
		});
		
	}else{
		response.writeHead(404);
		response.end('Not found');	
	}
});
app.listen(3000);
