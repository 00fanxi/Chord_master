function openConnection(){
	window.open("https://study-nodejs-admrb.run.goorm.io/connect_control", "connection","toolbar=yes,scrollbars=yes,resizable=yes,top=20,left=400,width=800,height=950")
}

function for_connect(){
	var str = document.body.innerHTML;
	var match1      = str.match(/<!--data.....-->/);
	var match2      = str.match(/<!--data...-->/);
	var firstIndex = str.indexOf(match1)+16;
	var lastIndex = str.indexOf(match2);
	var content = str.slice(firstIndex,lastIndex);
	
	var match1 = content.match(/<!--port'.n.d.ti.leS-->/g)
	var match2 = content.match(/<!--port'.n.d.ti.leE-->/g)
	var listobject = {};
	
	for(var i = 0;i<match1.length;i++){
		var firstIndex = content.indexOf(match1[i])+23;
		var lastIndex = content.indexOf(match2[i]);
		listobject[i] = content.slice(firstIndex,lastIndex);
	}
	var west_opp = ''
	for(var index in listobject){
		west_opp += '<option>' + listobject[index] + '</option>';
	}
	var east_opp = west_opp;

}

//현재 페이지 변경 사항 저장

function saving_content(){
	var str = document.body.innerHTML;
	var match1      = str.match(/<!--data.....-->/);
	var match2      = str.match(/<!--data...-->/);
	var firstIndex = str.indexOf(match1)+16;
	var lastIndex = str.indexOf(match2);
	var content = str.slice(firstIndex,lastIndex);
	
	
	//저장해야되는 포트의 개수
	var matchl = content.match(/<!--sharen.mS/g);
	var times = matchl.length;
	
	//sharenum의 수들은 순서가 무작위이기 때문에 순서대로의 크기를 알아내야 한다.
	//sharenum을 순서대로 shareobject 겍체에 담는다.
	var contentshare = content;
	var shareobject = {};
	var time = 0;
	
	for(var i = 0;i<times;i++){
	
		var matchsh1 = contentshare.match(/<!--shar.numS/);
		var matchsh2 = contentshare.match(/shar.numS-->/);

		var Indexsh1 = matchsh1.index+13;
		var Indexsh2 = matchsh2.index;

		shareobject[i] = Number(contentshare.slice(Indexsh1,Indexsh2));

		Indexsh1 = Indexsh1 - 13;
		Indexsh2 = Indexsh2 + 12;

		contentshare = contentshare.slice(0,Indexsh1) + contentshare.slice(Indexsh2);
	}
	
	//포트의 개수만큼 포트별로 문서를 잘라서 가져온 값을 넣는다.
	
	var content_out = ""
	var time = 0
	
	for( var shnum in shareobject){
		var j = shareobject[shnum];
		var patternj1 = new RegExp("<!--shar.numS"+j+"sharenu.S-->");
		var patternj2 = new RegExp("<!--shar.numE"+j+"sharenu.E-->");

		var matchj1 = content.match(patternj1);
		var matchj2 = content.match(patternj2);

		var Indexj1 = matchj1.index;
		var Indexj2 = matchj2.index+25+j.toString().length;

		var contentj = content.slice(Indexj1,Indexj2);
	
		
		//포트별로 값을 가져온다.
		var content_in={}
		for(var i = 1;i<101;i++){
				content_in["u"+i] = document.querySelector('#p'+j+' .u'+i).value;
				content_in["r"+i] = document.querySelector('#p'+j+' .r'+i).value;
		}
		
		
		//값을 문서상에 넣고 저장한다. 먼저 u의 값을 넣고 그다음 r의 값을 넣고 index와 indexlast로 이어나간다.
		
		var Indexlast = 0;

		for(var i = 1;i<101;i++){

		var pattern = new RegExp("usage ."+i); 

		var match3 = contentj.match(pattern);

		var Index = match3.index+9+i.toString().length;

			if(i===1){
				content_out += contentj.slice(0,Index)+""+"value="+'"'+content_in["u"+i]+'"'+" ";
			}else{
				content_out += contentj.slice(Indexlast,Index)+" "+"value="+'"'+content_in["u"+i]+'"'+" ";	
			}
			 Indexlast = Index;
			
			var patternr = new RegExp("ref ."+i);
			
			var match4 = contentj.match(patternr);
			
			var Index = match4.index+7+i.toString().length;
			
			content_out += contentj.slice(Indexlast,Index)+" "+"value="+'"'+content_in["r"+i]+'"'+" ";	
			
			Indexlast = Index;
		}

		content_out += contentj.slice(Indexlast);
		
	}	
		
	document.querySelector(".save_content").value = content_out;
}


//새 포트 생성 폼에서 직접입력시 숫자 입력창 표시

function selfInput(){
	if(document.querySelector('.port_number').value==="others"){
		document.querySelector('.port_number_selfInput').style.display="block"
	}else{
		document.querySelector('.port_number_selfInput').style.display="none"
	}
}

//새 노드 생성 폼 나타났다 사라지기

function newnodeform(){
	document.querySelector(".newnodeform").style.display = "flex";
}

function newnodequit(){
	document.querySelector(".newnodeform").style.display = "none";
}

//새 포트 생성 폼 나타났다 사라지기
function newportform(){
	document.querySelector(".newportform").style.display = "flex";
}

function newportquit(){
	document.querySelector(".newportform").style.display = "none";
}

//포트 삭제 버튼 활성화

function portcontrol(self){

	if(self.value === '포트관리'){
		var count = 2;
		var i = 0;
		while(count>1){
			if(document.querySelector(`#p${i} .deleteport`)!=null){
			document.querySelector(`#p${i} .deleteport`).style.display='block';
			}
			var k = document.body.innerHTML;
			count = (k.match(/<input type="submit" class="deleteport" title="포트 삭제" value="포트 삭제" style="display: none;">/g) || []).length;
			i++;
		}
		self.value = '포트관리 닫기'	
	}else{
		var i = 0
		var count = 2;
		while(count>1){
			if(document.querySelector(`#p${i} .deleteport`)!=null){
			document.querySelector(`#p${i} .deleteport`).style.display='none';
			}
			var k = document.body.innerHTML;
			count = (k.match(/<input type="submit" class="deleteport" title="포트 삭제" value="포트 삭제" style="display: block;">/g) || []).length;
			i++;
		}
		self.value = '포트관리'
	}
}

//현재 노드 삭제하기 전 확인 창

function check() {
	var check = confirm("현재 노드를 삭제하시겠습니까?");
	if(check === true){
		return true;
	}else{
		return false;
	}
}

//포트 삭제하기 전 확인 창
function checkDeletePort() {
	var check = confirm("한번 포트를 삭제하면 되돌릴 수 없습니다. 포트 삭제를 진행하시겠습니까?");
	if(check === true){
		return true;
	}else{
		return false;
	}
}


// MDF100펼쳐보기
function spread(self){
	if(self.value === '펼쳐보기'){
		document.querySelector("#p+num .port").style.display='inline';
		document.querySelector(".use").style.display='inline';
		document.querySelector(".refer").style.display='inline';
		for(var i = 1;i<101;i++){
			document.querySelector('.u'+i).style.display='inline';
			document.querySelector('.r'+i).style.display='inline';
		}
		self.value = '닫기'
	}else{
		document.querySelector('.port').style.display='none';
		document.querySelector('.use').style.display='none';
		document.querySelector('.refer').style.display='none';
		for(var i = 1;i<101;i++){
			document.querySelector('.u'+i).style.display='none';
			document.querySelector('.r'+i).style.display='none';
		}
		self.value = '펼쳐보기'
	}
}

// CDF128 펼쳐보기
function spreadCDF128(self){
	if(self.value === '펼쳐보기'){
		for(var i = 1;i<5;i++){
			document.querySelector(".use"+i).style.display='inline';
			document.querySelector(".refer"+i).style.display='inline';
		}
		for(var i = 1;i<101;i++){
			document.querySelector('.u'+i).style.display='inline';
			document.querySelector('.r'+i).style.display='inline';
		}
		self.value = '닫기'
	}else{
		for(var i = 1;i<5;i++){
			document.querySelector(".use"+i).style.display='none';
			document.querySelector(".refer"+i).style.display='none';
		}
		for(var i = 1;i<101;i++){
			document.querySelector('.u'+i).style.display='none';
			document.querySelector('.r'+i).style.display='none';
		}
		self.value = '펼쳐보기'
	}
}


		


















