function connect_searching(){
	document.querySelector('#header_info').submit();
//	document.querySelector('#center_info').submit();
//	document.querySelector('#west_info').submit();
//	document.querySelector('#east_info').submit();
}

function connect_searching_center(){
	document.querySelector('.center_change').value="1";
	document.querySelector('#header_info').submit();
}

