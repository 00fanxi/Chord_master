var http = require('http');
var fs = require('fs');
var url = require('url');
var qs = require('querystring');
var template = require('./lib/template.js')


//서버 만들기

var app = http.createServer(function(request,response){
	var _url = request.url;
	var queryData = url.parse(_url,true).query;
	var pathname = url.parse(_url,true).pathname;
	if(pathname === '/'){
		if(queryData.id === undefined){
			fs.readdir('linebook/data',function(error,filelist){
				fs.readFile(`linebook/linebook.css`,'utf8',function(err,CSS){
					fs.readFile(`linebook/linebook.js`,'utf8',function(err,JS){
						var title = 'Home';
						var list = template.List(filelist,title);
						var HTML = template.HTML(title,CSS,JS,list,"","");
						response.writeHead(200);
						response.end(HTML);
					});
				});		
			});
		}else{
			fs.readdir('linebook/data',function(error,filelist){	
				fs.readFile(`linebook/data/${queryData.id}`,'utf8',function(err,data){		
					fs.readFile(`linebook/linebook.css`,'utf8',function(err,CSS){
						fs.readFile(`linebook/linebook.js`,'utf8',function(err,JS){
							var title = queryData.id;
							var list = template.List(filelist,title);
							var newportform = template.NEWPORTFORM(filelist,title);
							var HTML = template.HTML(title,CSS,JS,list,data,newportform);
							response.writeHead(200);
							response.end(HTML);
						});
					});
				});
			});
		}
		
	//새로운 노드 만들기
	
	}else if(pathname==='/create_newnode'){
		var body = '';
		request.on('data',function(data){
			body = body + data;
		});
		request.on('end',function(){
			var post = qs.parse(body);
			var title = post.node_name;
			var description = '';
			fs.writeFile(`linebook/data/${title}`,description,'utf8',function(err){
				response.writeHead(302, {Location:encodeURI(`/?id=${title}`)})
				response.end();	
			});
		});
		
	//새로운 포트 만들기 
	}else if(pathname==="/create_newport"){
	var body = '';
	request.on('data',function(data){
		body = body + data;
	});
	request.on('end',function(){
		var post = qs.parse(body);
		var thisnode = post.thisnode;
		var port_name = post.port_name;
		var thisnode = post.thisnode;
		var oppnode = post.oppnode;
		var cable_type = post.cable_type;
		var port_type = post.port_type;
 		fs.readFile(`linebook/data/${thisnode}`,'utf8',function(err,counti){
			fs.readFile(`linebook/data/${oppnode}`,'utf8',function(err,countiopp){
				for(var i = 0;true;i++){
					if(counti.indexOf(`<div class="mdf100 full" id="p${i}">`)===-1 && countiopp.indexOf(`<div class="mdf100 full" id="p${i}">`)===-1 ){	
						if(port_type==="MDF"){
						var newport = template.MDF100(port_name,thisnode,oppnode,cable_type,i);
						fs.appendFile(`linebook/data/${thisnode}`,newport,'utf8',function(err){
						});
						var oppport = template.MDF100(port_name,oppnode,thisnode,cable_type,i);
						fs.appendFile(`linebook/data/${oppnode}`,oppport,'utf8',function(err){
							response.writeHead(302,{Location:encodeURI(`/?id=${thisnode}`)});
							response.end();	
						});
						// }else if(port_type==="CDF"){
						// 	var newport = template.CDF128(port_name,thisnode,oppnode,cable_type);
						// 	fs.appendFile(`linebook/data/${thisnode}`,newport,'utf8',function(err){
						// 	});
						// 	var oppport = template.CDF128(port_name,oppnode,thisnode,cable_type);
						// 	fs.appendFile(`linebook/data/${oppnode}`,oppport,'utf8',function(err){
						// 		response.writeHead(302,{Location:encodeURI(`/?id=${thisnode}`)});
						// 		response.end();	
						// 	});
						}else{
								var newport = template.MDF100(port_name,thisnode,oppnode,cable_type,i);
							fs.appendFile(`linebook/data/${thisnode}`,newport,'utf8',function(err){
							});
							var oppport = template.MDF100(port_name,oppnode,thisnode,cable_type,i);
							fs.appendFile(`linebook/data/${oppnode}`,oppport,'utf8',function(err){
								response.writeHead(302,{Location:encodeURI(`/?id=${thisnode}`)});
								response.end();	
							});
						}
						
						break;
						
					}else{
						continue;
					}
				}
			}); 
		}); 
	}); 	
		//node 삭제
		
	}else if(pathname==="/delete_process"){
		var body = '';
		request.on('data',function(data){
			body = body + data;
		});
		request.on('end',function(){
			var post = qs.parse(body);
			var id = post.id;
			fs.unlink(`linebook/data/${id}`,function(err){
				response.writeHead(302, {Location:`/`});
				response.end();	
			})
		}); 

//포트 삭제
		
	}else if(pathname==="/delete_port"){
		var body = '';
		request.on('data',function(data){
			body = body + data;
		});
		request.on('end',function(){
			var post = qs.parse(body);
			var thisnode = post.thisnode;
			var oppnode = post.oppnode;
			var num = post.num;
			fs.readFile(`linebook/data/${thisnode}`,'utf8',function(err,buffer){
				fs.unlink(`linebook/data/${thisnode}`,function(err){
				})
				var check = buffer.indexOf(`<!--startp${num}-->`);
				var check2 = buffer.indexOf(`</div> <!--endp${num}-->`) + 19;

				var point1 = buffer.slice(0,check);
				var point2 = buffer.slice(check2);
				fs.writeFile(`linebook/data/${thisnode}`,point1,"utf8",function(err){

				})
				fs.appendFile(`linebook/data/${thisnode}`,point2,"utf8",function(err){

				})
			});	
			fs.readFile(`linebook/data/${oppnode}`,'utf8',function(err,buffer){
				fs.unlink(`linebook/data/${oppnode}`,function(err){
				})
				var check = buffer.indexOf(`<!--startp${num}-->`);
				var check2 = buffer.indexOf(`</div> <!--endp${num}-->`) + 19;

				var point1 = buffer.slice(0,check);
				var point2 = buffer.slice(check2);
				fs.writeFile(`linebook/data/${oppnode}`,point1,"utf8",function(err){

				})
				fs.appendFile(`linebook/data/${oppnode}`,point2,"utf8",function(err){

				})
				response.writeHead(302,{Location:encodeURI(`/?id=${thisnode}`)});
				response.end();	
			});	
		});
	
//없는 페이지 404
	
	}else{
		response.writeHead(404);
		response.end('Not found');	
	}
});
app.listen(3000);
