function selfInput(){
	console.log(document.querySelector('.port_number').value)
	if(document.querySelector('.port_number').value==="others"){
		document.querySelector('.port_number_selfInput').style.display="block"
	}else{
		document.querySelector('.port_number_selfInput').style.display="none"
	}
}

//새 노드 생성 폼 나타났다 사라지기

function newnodeform(){
	document.querySelector(".newnodeform").style.display = "flex";
}

function newnodequit(){
	document.querySelector(".newnodeform").style.display = "none";
}

//새 포트 생성 폼 나타났다 사라지기
function newportform(){
	document.querySelector(".newportform").style.display = "flex";
}

function newportquit(){
	document.querySelector(".newportform").style.display = "none";
}

//포트 삭제 버튼 활성화

function portcontrol(self){

	if(self.value === '포트관리'){
		var count = 2;
		var i = 0;
		while(count>1){
			if(document.querySelector(`#p${i} .deleteport`)!=null){
			document.querySelector(`#p${i} .deleteport`).style.display='block';
			}
			var k = document.body.innerHTML;
			count = (k.match(/<input type="submit" class="deleteport" title="포트 삭제" value="포트 삭제" style="display: none;">/g) || []).length;
			i++;
		}
		self.value = '포트관리 닫기'	
	}else{
		var i = 0
		var count = 2;
		while(count>1){
			if(document.querySelector(`#p${i} .deleteport`)!=null){
			document.querySelector(`#p${i} .deleteport`).style.display='none';
			}
			var k = document.body.innerHTML;
			count = (k.match(/<input type="submit" class="deleteport" title="포트 삭제" value="포트 삭제" style="display: block;">/g) || []).length;
			i++;
		}
		self.value = '포트관리'
	}
}

//현재 노드 삭제하기 전 확인 창

function check() {
	var check = confirm("현재 노드를 삭제하시겠습니까?");
	if(check === true){
		return true;
	}else{
		return false;
	}
}

//포트 삭제하기 전 확인 창
function checkDeletePort() {
	var check = confirm("한번 포트를 삭제하면 되돌릴 수 없습니다. 포트 삭제를 진행하시겠습니까?");
	if(check === true){
		return true;
	}else{
		return false;
	}
}

// MDF100펼쳐보기
function spread(self){
	if(self.value === '펼쳐보기'){
		document.querySelector("#p+num .port").style.display='inline';
		document.querySelector(".use").style.display='inline';
		document.querySelector(".refer").style.display='inline';
		for(var i = 1;i<101;i++){
			document.querySelector('.u'+i).style.display='inline';
			document.querySelector('.r'+i).style.display='inline';
		}
		self.value = '닫기'
	}else{
		document.querySelector('.port').style.display='none';
		document.querySelector('.use').style.display='none';
		document.querySelector('.refer').style.display='none';
		for(var i = 1;i<101;i++){
			document.querySelector('.u'+i).style.display='none';
			document.querySelector('.r'+i).style.display='none';
		}
		self.value = '펼쳐보기'
	}
}

// CDF128 펼쳐보기
function spreadCDF128(self){
	if(self.value === '펼쳐보기'){
		for(var i = 1;i<5;i++){
			document.querySelector(".use"+i).style.display='inline';
			document.querySelector(".refer"+i).style.display='inline';
		}
		for(var i = 1;i<101;i++){
			document.querySelector('.u'+i).style.display='inline';
			document.querySelector('.r'+i).style.display='inline';
		}
		self.value = '닫기'
	}else{
		for(var i = 1;i<5;i++){
			document.querySelector(".use"+i).style.display='none';
			document.querySelector(".refer"+i).style.display='none';
		}
		for(var i = 1;i<101;i++){
			document.querySelector('.u'+i).style.display='none';
			document.querySelector('.r'+i).style.display='none';
		}
		self.value = '펼쳐보기'
	}
}


		


















