var M = {
	v:'v',
	f:function(){
		console.log(this.v);
	}
}

module.exports = M;