/*
function a(){
	console.log('A');
}
*/


//이름이 없는 함수는 익명함수

//변수에 함수지정이 가능하다 = javascript에서 함수는 값이다.

var a = function(){
	console.log('A');
}

function slowfunc(callback){
	callback();
}

slowfunc(a);

//slowfunc의 parameter인 callback의 값으로 a를 지정.
// 그 말은 callback의 값은 함수 a의 값.
// 따라서 slowfunc를 실행하면 a의 값을 받아 A를 출력한다.