var args = process.argv;
console.log(args[2]);
